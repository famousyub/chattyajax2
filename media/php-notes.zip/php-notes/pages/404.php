<div class="row">
    <div class="col-md-12">
        <div class="error-template">
            <h1 class="text-center text-danger">Oops!</h1>
            <h2 class="text-center text-danger">404 Not Found</h2>
            <div class="error-details text-center text-muted">
                Sorry, an error has occured, Requested page not found!
            </div>
            <div class="error-actions text-center">
                <a href="./" class="btn btn-primary btn-lg"><span class="glyphicon glyphicon-home"></span>
                    Take Me Home </a>
            </div>
        </div>
    </div>
</div>